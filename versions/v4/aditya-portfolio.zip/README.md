# Aditya Shrivastav — Product portfolio

A dependency-free static website. No install or build is needed.

## Use
- Deploy the contents of `dist/` to any static host.
- Or use `exports/index.html`, the self-contained single-file edition.
- The downloadable ZIP contains `index.html`, the local `assets/` folder and this README.
- Optional local preview: `npm run dev` uses only Node built-ins. It is not needed for hosting.

## Edit
Content, URLs, CSS and JavaScript are in `dist/index.html`. Update each project's `href` when a deployment is confirmed. Regenerate the exports after editing the main page.

## Links and capture status — 21 September 2026
The current destinations were supplied by Aditya: momspg.com, bellevie.rentok.com, nyranest.com, alliancehomes.co.in, onboardhub.rentok.com, and demohub.rentok.com.

Actual public website screenshots were captured for Moms PG, Belle-Vie, Alliance Homes, Onboard Hub and Demo Hub. Alliance redirects to www.alliancehomes.co.in. Onboard Hub and Demo Hub require sign-in; their public entry screens are used and labelled. No authentication or form submission was performed.

Nyra Nest returned a TLS-related 502 error in the capture browser. Its supplied link is used, and the previous thumbnail remains explicitly labelled "Concept preview". Replace it with a genuine screenshot when provided or when the site can be captured. This is the remaining thumbnail task.

The flagship GitHub links are retained as optional source links; earlier connected GitHub checks returned 404 and could not confirm access. Booking Agent and Support Agent have no outbound links.

## Content and visuals
Metrics come from the attached Aditya Shrivastav resume: AI vertical ARR Rs 25–30L, adoption 45% to 72%, and 10,000+ inbound AI sales leads. Demo Hub's expanded snapshot uses 1,500 demos and 200 paid conversions from the same resume.

Five thumbnails now use genuine website captures. Nyra Nest alone retains a labelled concept preview with generated illustrative interior imagery. Agent conversations remain clearly labelled examples, not a live chat interface. The original portrait and generated caricature are unchanged.

## Newsletter and share
Signup opens a mailto request to aditya@saros.in. It never records a subscription, stores the email, or contacts an invented API. A visitor must send the email. An icon-based Email contact link above the newsletter provides a direct way to reach Aditya. The repeated raw-email note inside the newsletter has been removed. Sharing uses the native Web Share API where available, falls back to clipboard, then a selectable link. Cancelling native share does not trigger a copy.

## Checks
The local static server loaded the page in the browser. Desktop, 320px and 390px mobile-frame, and 625px tablet-frame layouts were visually reviewed; horizontal overflow was checked. All eight current image instances loaded (eight unique local assets). Fragment links, unique IDs, SVG validity and JavaScript syntax passed. Mailto encoding, invalid input, native sharing, cancellation, clipboard and manual fallback branches passed focused checks. The snapshot disclosure and copy fallback were exercised in the browser. Reduced-motion styles disable movement. No email was sent during testing.

## Redesign — version 2
- Personal hero with a photo-based editorial caricature and the supplied original photo in About.
- Larger flagship product stories, handwriting-style annotations and lime accents.
- Brief entrance, underline, section and conversation animations, all disabled with prefers-reduced-motion. Content remains visible without JavaScript.
- Agent outbound URLs removed from the current page.
- Newsletter/share behavior retained; no-JS visitors receive a manual share instruction.
- Version 1 preserved in Git history and in `versions/v1/`.
- Portrait generated with the built-in image-generation tool from the supplied reference. Prompt: premium editorial ink-and-gouache caricature cutout preserving swept black hair, full beard, sunglasses, blue kurta and cream vest; subtle exaggeration, hand in pocket, transparent background, no scenery, lettering or props. The original photo remains unchanged.

## Redesign — version 3
- Replaced the soft editorial theme with oversized sans-serif type, bold framed compositions, cobalt, yellow and orange panels, and strong black outlines.
- Body text is 18–20px, navigation 16px, and meaningful secondary labels at least 14px (miniature illustrative UI and decorative stickers are exceptions).
- Main foreground/background pairs exceed WCAG AA contrast: white on cobalt 6.99:1, ink on orange 7.00:1, ink on warm white 17.02:1.
- Content stays fully opaque at all times. Brief entrance movement and portrait/card interactions respect reduced-motion preferences.
- The personal photos, products, accurate link labels, agent descriptions and newsletter behavior remain intact.
- Version 2 preserved in Git history and in `versions/v2/`; version 1 remains in `versions/v1/`.

## Update — version 4
- Replaced hobby numbers with labelled badminton, AI chip, gamepad and chair icons.
- Added LinkedIn, Email and My contact cards above the newsletter; phone links to +91-8296876536.
- Updated all six website URLs and installed five actual public-site captures.
- Nyra Nest's remaining concept thumbnail is explicitly identified; see capture status above.
- Preserved version 3 in `versions/v3/` and Git history.

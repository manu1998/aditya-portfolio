# Aditya Shrivastav — Product portfolio

A dependency-free static website. No install or build is needed.

## Use
- Deploy the contents of `dist/` to any static host.
- Or use `exports/index.html`, the self-contained single-file edition.
- The downloadable ZIP contains `index.html`, the local `assets/` folder and this README.
- Optional local preview: `npm run dev` uses only Node built-ins. It is not needed for hosting.

## Edit
Content, URLs, CSS and JavaScript are in `dist/index.html`. Update each project's `href` when a deployment is confirmed. Regenerate the exports after editing the main page.

## Link verification — 20 September 2026
The connected GitHub service returned 404 for Atlas987/onboardhub, Atlas987/demobook, Atlas987/Belle-Vie and Atlas987/Nyra-nest. This can mean inaccessible/private/missing repositories. No accessible existing portfolio repository was found; existing work was not overwritten.

The supplied product URLs could not be verified through the web service. They have been retained exactly as provided, with no replacement URL invented. Belle-Vie and Nyra Nest use View source; Alliance Homes uses View design. Booking Agent and Support Agent have no outbound links; only capability descriptions and illustrative conversations are shown. Confirm outbound availability before using the portfolio in an application.

## Content and visuals
Metrics come from the attached Aditya Shrivastav resume: AI vertical ARR Rs 25–30L, adoption 45% to 72%, and 10,000+ inbound AI sales leads. Demo Hub's expanded snapshot uses 1,500 demos and 200 paid conversions from the same resume.

Flagship thumbnails are original schematic interface illustrations, not screenshots. Agent conversations are clearly labelled examples, not a live chat interface. The website previews are original concepts with generated illustrative interior imagery; they are not verified designs or photos of the named properties. Each category is labelled on the page. Replace these with actual screenshots when available.

## Newsletter and share
Signup opens a mailto request to aditya@saros.in. It never records a subscription, stores the email, or contacts an invented API. A visitor must send the email. A visible direct-email fallback is provided. Sharing uses the native Web Share API where available, falls back to clipboard, then a selectable link. Cancelling native share does not trigger a copy.

## Checks
The local static server loaded the page in the browser. Desktop, 320px and 390px mobile-frame, and 625px tablet-frame layouts were visually reviewed; horizontal overflow was checked. All eight current image instances loaded (six unique local assets). Fragment links, unique IDs, SVG validity and JavaScript syntax passed. Mailto encoding, invalid input, native sharing, cancellation, clipboard and manual fallback branches passed focused checks. The snapshot disclosure and copy fallback were exercised in the browser. Reduced-motion styles disable movement. No email was sent during testing.

## Redesign — version 2
- Personal hero with a photo-based editorial caricature and the supplied original photo in About.
- Larger flagship product stories, handwriting-style annotations and lime accents.
- Brief entrance, underline, section and conversation animations, all disabled with prefers-reduced-motion. Content remains visible without JavaScript.
- Agent outbound URLs removed from the current page.
- Newsletter/share behavior retained; no-JS visitors receive a manual share instruction.
- Version 1 preserved in Git history and in `versions/v1/`.
- Portrait generated with the built-in image-generation tool from the supplied reference. Prompt: premium editorial ink-and-gouache caricature cutout preserving swept black hair, full beard, sunglasses, blue kurta and cream vest; subtle exaggeration, hand in pocket, transparent background, no scenery, lettering or props. The original photo remains unchanged.

## Redesign — version 3
- Replaced the soft editorial theme with oversized sans-serif type, bold framed compositions, cobalt, yellow and orange panels, and strong black outlines.
- Body text is 18–20px, navigation 16px, and meaningful secondary labels at least 14px (miniature illustrative UI and decorative stickers are exceptions).
- Main foreground/background pairs exceed WCAG AA contrast: white on cobalt 6.99:1, ink on orange 7.00:1, ink on warm white 17.02:1.
- Content stays fully opaque at all times. Brief entrance movement and portrait/card interactions respect reduced-motion preferences.
- The personal photos, products, accurate link labels, agent descriptions and newsletter behavior remain intact.
- Version 2 preserved in Git history and in `versions/v2/`; version 1 remains in `versions/v1/`.
